/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * coderRand_terminate.c
 *
 * Code generation for function 'coderRand_terminate'
 *
 */

/* Include files */
#include "coderRand.h"
#include "coderRand_terminate.h"

/* Function Definitions */
void coderRand_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (coderRand_terminate.c) */
