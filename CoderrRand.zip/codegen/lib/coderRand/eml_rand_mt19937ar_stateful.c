/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_rand_mt19937ar_stateful.c
 *
 * Code generation for function 'eml_rand_mt19937ar_stateful'
 *
 */

/* Include files */
#include "coderRand.h"
#include "eml_rand_mt19937ar_stateful.h"
#include "coderRand_data.h"

/* Function Definitions */
void state_not_empty_init(void)
{
  state_not_empty = false;
}

/* End of code generation (eml_rand_mt19937ar_stateful.c) */
