/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * coderRand_data.c
 *
 * Code generation for function 'coderRand_data'
 *
 */

/* Include files */
#include "coderRand.h"
#include "coderRand_data.h"

/* Variable Definitions */
unsigned int method;
unsigned int state;
unsigned int b_state[2];
boolean_T state_not_empty;

/* End of code generation (coderRand_data.c) */
