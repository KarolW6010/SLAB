/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * coderRand.h
 *
 * Code generation for function 'coderRand'
 *
 */

#ifndef CODERRAND_H
#define CODERRAND_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "coderRand_types.h"

/* Function Declarations */
extern double coderRand(void);

#endif

/* End of code generation (coderRand.h) */
