/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_coderRand_info.c
 *
 * Code generation for function 'coderRand'
 *
 */

/* Include files */
#include "_coder_coderRand_info.h"

/* Function Definitions */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[23] = {
    "789ced5dcb6f234919ef2cb3434608362caf595682ccb25a8166143f13db2b21f9edf815bf92d89bddd9a4dd5db6dbee97bbdbaf1c50242e1cf680e0c2610f9c"
    "d08a0bec8939a1c089e38ad781337f00173863bb5d8edd71c53d71bb6df75449999aaaaf53bfaa2f5f7d5ff5f75555135bf1f41641105febffbcd6ff79fc6762",
    "98beaa66c4ce287f8d984e5afad628dfd594617a9d7830f57b90fee928a7045e015d452db00c0f8e5a5c1948fd024f7260dc0c2d700c4ff2ca714f0484046481"
    "6d037a48a9302c3866389012260a874cbfc0452748e3c28034f87fa806a846a1c511524dbee92e3b592026f8f36bc4f81fe8e48f0fc19f9d511da47f18791e7a",
    "df76220349b6354849606d6120371441b48504beddaf65047e372b9194c250c046093490f2244fef719afe5e20faf350677fb5394c8f88edc9a27f1e9e5efe3c"
    "d09489f1730f8675527f9083f2a278da84fa7bc004f17e7f4f3cd856620e1ea47f184f958622909584aa4472bb0359956de9c0712a10b4e59d7687b76c530481",
    "2d0b5d1be0581bcb946d1ca9b064d936e051a5c50f732810e6c9833ffcbd47ff0c982c7f66cbfbcaf0ba88f6f4cadfb7107850fe209da6938d4bc671d0c97578"
    "9a69761cd2c1be7ba21fd93938f3fa4120ca66b58fe7f1ecfe4fcbdd33bfd972d767c139239f0f867cde5f0f480c2f3314b13a7dff977be2c1b6e83978903e90",
    "93eca282224a4c9b54806d26135509324f7eae3e2fbef50f6c079684b7e87cfc36020fca25a4d3c950d11bf77105b15304997c4a28ba9b9d20b603af941db8fa"
    "c8b0f5fdb6a64c8c9fdb1ed60d54d7609c66bd4f503572f09239e6e78b05f18a483cb50ed20dd7f723e1c0fadd1a7866e9f75a5aec81a340e4b4100c26295f81",
    "763b9ab143ebe877abcc67943ce895bf2f21c6f168943f9eaa7de657f3bd516e1feb7f1181a3979f6f20fa01f909e99005e7b22239197ae1f5ff7dedc1f58278"
    "1f23f1d43a485f8afc8c983758339868170a6fffe26fd82e2c09cf34bbe0ea9cd2e913caed28b0c1b31310e8f68e9410b60beb66172e10fd3476fd1f1eebff2b",
    "447b7af9f65d041ee41ba48f551847551d075ebba7afcbfa2ca8b45895be2a7bf0c582780c124fad83f4e5d8835bcc5c45bce89337441c1fd874fb100d25c2ac"
    "a35e208b6d4a29f0c7d1422ee0b3905f08cff3bbc7a74f2edf312c7ef075041ee427a4df62c1a87e53df1f2e346562e2b9ad09fa72e5688f334f6eaee94f7f8a",
    "edc3bada07bd713c6fce15f0f16c3cedaee6f3f96aac7e5a695a297e8cedc3dde3d327977b96b30f0f35e59b7e3c1cd6b5185e7139b17dc0f6613df1b07d30a6"
    "fd45ed4303d13ee423a42f7b5e3f21cb7298a954429c3835be0b44ff8d95cbe786c59de7e9e5be5ae6c82ede577a97b800b6ff1f9bca29f3f7215cbff80ede57",
    "bab67a5fafdf486adac53a23bb03dc41d6c367cb2557f254b690df08c71566e7304dc71522ab8b2bc835c945097c15c7158c88336b9989e30a16c333cb3ed4eb"
    "9954acb19fda4f38d2b96e2b0fa87c888d5ac73ee0797ef7f8f4c9e50ae30a9005a37a1c5758448eccf41bf97ff51f01ef57dd74fbc0160e58d647bb9a2e3151",
    "e9951351df653b62a17d49d83edc3d3e7d72b9c2b8c292ecc3ab1557c0f6c16a78d83e18d33ef62fcdce619af62f450df32fbd8dc0837c83f49b108ae2f0f95c"
    "1e529a76306daa7fa98ec453eb207d49f1a85bcc5cc13948ec5f5a229e59f6a11872249bc7f221737896eb06e578aa1ea9fb62d6b10f789edf3d3eb3fd4b6f22",
    "f0203f21fd360bd4fa4d3d075d42e2a975906ec4b9f8dbbc33753fd26f1efd04bf376cba5d88383d15d653e2954ea899008ea36eeef2e004c71db05d58925f69"
    "5decc2cbfa95b05d989dc384ed823978d82e18d3fea2f79b9188f6211f217d59f3f94915f083ba96665c17887e1b2a8f1765c3f6a7a2eee7d8e953067540542f",
    "a45dd5fed4cfee8907db8acdc183f4c5f7a7f63965ee3d48fffee5bbd82fb4e97a9e669544342a8bbe98c2049d54201c2dcbc5b075f43c9ebfd3695adeec86e9"
    "f12f23f076fa94a11eefdbb0812edf54bfce31124fad83f485de035541987c0b54858230530ff97f87efb7db7cbdce9fd5bd4929d188c5522e4900978257c8ee",
    "5b48afe3f93c3b87695afede352c1efc16020ff20dd2875f66d8637805483cc9ee55588154d2fdbad171838db50379249e5a07e92fbd1e18fc3c1d72cdf614b2"
    "cd76c3b6159c3bfb2db6039b6f07da5e97db0312c94c25ec53ce3c643e1562380bdd73baa81fa7aa291313cf6d4dd097e6c761e4f336c932b4eae137571e772b",
    "a6adff1919345b246b9aff9e165a65161877ce3889c453eb20dd8073c62aa7460adfc475ff5f3ffb04fb73d655dfebbd5f22215e3a9a9e0c7df2818375823c28"
    "9e292e1f611d7d8fe7f1ecfe4fcbddee58af8b88f6f4f20bf5f781fc8274f5d32bc3119f53820456a5e7af17c47b8ec453eb20dde0f7c249d60d25c6ccfdff58",
    "efafafded7bbce8fed07ba4cde536fdb4f9a077657a89ace870e82d6d1fbd788dfc7f37a3a4dcbe10f0ddbb7f3585326269edb9aa06bfc3e3c2955199eaa3556"
    "15bfbdbe271e6ceba3397890fe52eb05b9464a8056bf5e3afaf796eb67cc39d3bf5ff68df7f37fc7f660497866d9835eb713f791d14a75df4e652242a11e6d79",
    "3a116c0fd6755e9bfb9d9b77fc6afede287f66981fe875443f76fa94415d85158481437e53fd4071249e5a07e98bbd3f0ebc85434eade21cf99f4edec37eff4d"
    "d7ffdea62773dc64c3fb8d60ed38172b28cd7098b2d0fe4d3c8f67f71fe507ba42b4a7975fdf47e0417e41ba66fdcfc8c116c32a71fea8c50189a156a6f7d776",
    "fffeccb8af966d66eedfbffac37fff85f5ffa6ebff4cbb190a540edbdee39cbb474538de193d632d14f7c5fa7f76ff97b5ef47ef3d101afd2f53244b4a7b70d5"
    "bfba7dfc8beaff933978906e8cfe7faaf26d42764cd4ff78dfcf12f1ccd2ffe5da41b6c4b30a5d10b8488b3f749523c18485ee7bc0fa7f76ff51faffe788f6f4",
    "f2eb47083cc82f48d7e87f5214d95e61a8cca22d9e5218818ff35996a4c0e879a3e2d47abfaf5c19f5e2bc46f2347bb3df6ad17d64e539f8906e8c7d40b37505"
    "fb44cb5fa9e3f8f1a6db0b814cd5cb24190bd12e6f5d2e3941fa4cec59e8bc009edfb3c7a54f1e8d8b0f6c6bcac4f8b9ed611d23cb2229c92bdb3fb4e8bae208",
    "89a7d641fa22eb8a0187062b0bc82b73bf73efdffef1c758df6fbabeef14e372946d9c469d15a9c0b6eb99047f99b3d07da158dfcf1e973e79dcb39cdfe8bef6"
    "00fb8d66e73061bf913978d86f644cfb5f207e5f2f1f594d9998786e6b82bed47da44fca0c4f4a3d583b39be0b44ff0d954bff297e1fd08987df078cc653d3ab",
    "8287df078c691febfdbbc7a74b2eaf8a63bdff33447b7af9f903041ee427a46be3096d81a1039244f6a22ca9288067465f9cc1e70b74bd67ce609fe9f7915cfd"
    "af8cedc5a6db8bcbc4a12b742296b85c3943074a95c37497cb58687f9135ec052caa6e81c9f15d20fa6fec3da1c0b473058ccc933c81cf15e83997dee7d40af6",
    "235cbdc0fb4ad757efebbd5fa21968653877afe4b6e725672be400be3677445847efe3793cbbffcbda578acf15a0f0d43a7caee0be786a7a55f0f0b90263dac7"
    "f7c9cd1e972e79f457577ddf04c3d3a09b655bf2a6da831c124fad837483ec0164d72ad611a76f2af89e894db7078785c352a9e0ca1495189969d4e3c97475bf",
    "63a17831fe4eccec71e992c76bca307bf04d041ee423a46bec0190244197df6b5def9b5ecafb819e7b4a869c33f5fde08fc90f705c60d3ed4197cf752ed32217"
    "8c35c351d91b4a34db82dd02e708fe0f7046db64", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 49712U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 0);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("coderRand"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(0.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\karol\\Desktop\\Conversion Practice\\coderRand.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (737443.64394675929));
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.5.0.944444 (R2018b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_coderRand_info.c) */
