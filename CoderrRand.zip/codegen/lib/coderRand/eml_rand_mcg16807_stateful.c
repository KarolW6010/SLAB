/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * eml_rand_mcg16807_stateful.c
 *
 * Code generation for function 'eml_rand_mcg16807_stateful'
 *
 */

/* Include files */
#include "coderRand.h"
#include "eml_rand_mcg16807_stateful.h"
#include "coderRand_data.h"

/* Function Definitions */
void eml_rand_mcg16807_stateful_init(void)
{
  state = 1144108930U;
}

/* End of code generation (eml_rand_mcg16807_stateful.c) */
