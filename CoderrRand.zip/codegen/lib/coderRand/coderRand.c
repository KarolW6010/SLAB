/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * coderRand.c
 *
 * Code generation for function 'coderRand'
 *
 */

/* Include files */
#include "coderRand.h"
#include "rand.h"

/* Function Definitions */
double coderRand(void)
{
  return b_rand();
}

/* End of code generation (coderRand.c) */
