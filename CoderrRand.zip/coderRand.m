function r = coderRand() %#codegen
r = rand();
